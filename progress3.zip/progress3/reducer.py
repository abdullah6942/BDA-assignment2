#!/usr/bin/env python3

import sys

current_word = None
current_article_ids = []

# Input comes from standard input
for line in sys.stdin:
    # Split the line into word and article_id
    word, article_id = line.strip().split('\t', 1)

    # Convert article_id to integer
    try:
        article_id = int(article_id)
    except ValueError:
        # If article_id is not a valid integer, skip this line
        continue

    # If the word is the same as the current word, add the article_id to the list
    if word == current_word:
        current_article_ids.append(article_id)
    else:
        # If the word is different, print the word and the list of article_ids
        if current_word:
            print(f"{current_word}\t{', '.join(map(str, current_article_ids))}")
        # Reset current_word and current_article_ids for the new word
        current_word = word
        current_article_ids = [article_id]

# Print the last word and article_ids
if current_word:
    print(f"{current_word}\t{', '.join(map(str, current_article_ids))}")


