#!/usr/bin/env python3

import sys

# Input comes from standard input
for line in sys.stdin:
    # Split the line into words
    words = line.strip().split(',')
    if len(words) == 2:
        article_id, section_text = words
        # Tokenize the section text into individual words
        words = section_text.split()
        # Emit key-value pairs where the word is the key and the article ID is the value
        for word in words:
            print(f"{word.lower()}\t{article_id}")



