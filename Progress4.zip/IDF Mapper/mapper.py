#!/usr/bin/env python3

import sys

current_word = None
article_ids = set()

for line in sys.stdin:
    line = line.strip()
    word, article_id = line.split('\t', 1)
    
    if current_word == word:
        article_ids.add(article_id)
    else:
        if current_word:
            idf = len(article_ids)
            print(f'{current_word}\t{idf}')
        current_word = word
        article_ids = {article_id}

if current_word:
    idf = len(article_ids)
    print(f'{current_word}\t{idf}')
