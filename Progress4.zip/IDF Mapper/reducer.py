#!/usr/bin/env python3

import sys
import re

for line in sys.stdin:
    line = line.strip()
    article_id, section_text = line.split('\t', 1)
    words = re.findall(r'\w+', section_text.lower())
    
    for word in set(words):  # Ensure each word is counted once per document
        print(f'{word}\t{article_id}')
