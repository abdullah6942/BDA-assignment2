{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "817fea2c-7db7-4123-a730-cf9e9f9be291",
   "metadata": {},
   "outputs": [],
   "source": [
    "#!/usr/bin/env python\n",
    "\n",
    "import sys\n",
    "\n",
    "current_doc_id = None\n",
    "tfidf_vector = {}\n",
    "\n",
    "for line in sys.stdin:\n",
    "    doc_id, word = line.strip().split('\\t')\n",
    "    if current_doc_id != doc_id:\n",
    "        if current_doc_id:\n",
    "            print(f\"{current_doc_id}\\t{tfidf_vector}\")\n",
    "        current_doc_id = doc_id\n",
    "        tfidf_vector = {}\n",
    "    tfidf_vector[word] = 1\n",
    "\n",
    "if current_doc_id:\n",
    "    print(f\"{current_doc_id}\\t{tfidf_vector}\")\n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
