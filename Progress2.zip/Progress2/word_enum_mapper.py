{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "5a140d40-335f-4b1d-a674-f95c2191100b",
   "metadata": {},
   "outputs": [],
   "source": [
    "#!/usr/bin/env python\n",
    "\n",
    "import sys\n",
    "\n",
    "for line in sys.stdin:\n",
    "    doc_id, content = line.strip().split('\\t')\n",
    "    words = content.split()\n",
    "    for word in words:\n",
    "        print(f\"{word}\\t{doc_id}\")\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "e84441fa-3b9c-4feb-af76-7c9097f6850f",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
